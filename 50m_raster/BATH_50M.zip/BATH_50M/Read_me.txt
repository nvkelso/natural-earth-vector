PRODUCTION TIPS

In Photoshop, select which depth layers to show and re-colorize as needed. There is no TIF version of the file provided.

Flatten the file when finished and save as a TIF image for use with the provided World (.tfw) file.

Applying the Median filter in Photoshop to the flattened image will generalize the detail.

The file is in the Geographic projection and uses the WGS84 datum.
